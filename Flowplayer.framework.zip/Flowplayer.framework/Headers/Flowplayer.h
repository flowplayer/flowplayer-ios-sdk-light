//
//  Flowplayer.h
//  Flowplayer
//
//  Created by Mathias Palm on 2019-01-07.
//  Copyright © 2019 com.appshack. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Flowplayer.
FOUNDATION_EXPORT double FlowplayerVersionNumber;

//! Project version string for Flowplayer.
FOUNDATION_EXPORT const unsigned char FlowplayerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Flowplayer/PublicHeader.h>
#import <Flowplayer/FLPlayerView.h>


